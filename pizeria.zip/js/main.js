/* PIZERIA — UI behaviour. Catalog, pricing and cart rules live in logic.js. */
(function () {
  'use strict';
  var L = window.PizeriaLogic;
  if (!L) return;

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  function el(tag, attrs, children) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (attrs[k] === null || attrs[k] === undefined) return;
      if (k === 'text') n.textContent = attrs[k];
      else if (k === 'class') n.className = attrs[k];
      else n.setAttribute(k, attrs[k]);
    });
    (children || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }

  function safeStorage() {
    try { var k = '__pz'; window.localStorage.setItem(k, '1'); window.localStorage.removeItem(k); return window.localStorage; }
    catch (e) { return null; }
  }

  var cart = L.createCart(safeStorage());

  /* ---------- Broken images: hide them instead of showing browser icons ---------- */
  document.addEventListener('error', function (e) {
    if (e.target && e.target.tagName === 'IMG') e.target.classList.add('img-failed');
  }, true);

  /* ---------- Toast ---------- */
  var toastEl = $('#toast'), toastTimer;
  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add('is-on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('is-on'); }, 2400);
  }

  /* ---------- Dialog helper (focus trap, Esc, focus return) ---------- */
  var FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]),[tabindex]:not([tabindex="-1"])';
  var openStack = [];
  function trapKey(e) {
    var top = openStack[openStack.length - 1];
    if (!top) return;
    if (e.key === 'Escape') { top.close(); return; }
    if (e.key !== 'Tab') return;
    var f = $$(FOCUSABLE, top.node).filter(function (n) { return n.offsetParent !== null || n === document.activeElement; });
    if (!f.length) { e.preventDefault(); top.node.focus(); return; }
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && (document.activeElement === first || document.activeElement === top.node)) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
  document.addEventListener('keydown', trapKey);

  function lockScroll(on) { document.body.classList.toggle('is-locked', on); }

  /* ---------- Cart drawer ---------- */
  var drawer = $('#cartDrawer'), scrim = $('#scrim'), cartBtn = $('#cartOpen');
  var drawerCtl = { node: drawer, trigger: null, close: closeCart };
  function openCart() {
    if (openStack.indexOf(drawerCtl) !== -1) return;
    drawerCtl.trigger = document.activeElement;
    scrim.hidden = false;
    requestAnimationFrame(function () { scrim.classList.add('is-on'); });
    drawer.classList.add('is-open'); drawer.setAttribute('aria-hidden', 'false');
    cartBtn.setAttribute('aria-expanded', 'true');
    openStack.push(drawerCtl); lockScroll(true);
    setTimeout(function () { $('#cartClose').focus(); }, 30);
  }
  function closeCart() {
    var i = openStack.indexOf(drawerCtl); if (i === -1) return;
    openStack.splice(i, 1);
    drawer.classList.remove('is-open'); drawer.setAttribute('aria-hidden', 'true');
    scrim.classList.remove('is-on'); setTimeout(function () { if (!scrim.classList.contains('is-on')) scrim.hidden = true; }, 350);
    cartBtn.setAttribute('aria-expanded', 'false');
    if (!openStack.length) lockScroll(false);
    var t = drawerCtl.trigger; if (t && t.focus && document.contains(t)) t.focus();
  }
  cartBtn.addEventListener('click', openCart);
  $('#cartClose').addEventListener('click', closeCart);
  scrim.addEventListener('click', function () { var top = openStack[openStack.length - 1]; if (top === drawerCtl) closeCart(); });
  $$('[data-close-cart]').forEach(function (a) { a.addEventListener('click', closeCart); });
  $('#cartClear').addEventListener('click', function () { cart.clear(); });

  /* ---------- Cart rendering ---------- */
  var listEl = $('#cartList'), emptyEl = $('#cartEmpty'), footEl = $('#cartFoot'), countEl = $('#cartCount');
  function renderCart() {
    var items = cart.items(), n = cart.count();
    countEl.textContent = n; countEl.hidden = n === 0;
    cartBtn.setAttribute('aria-label', 'Open cart, ' + n + (n === 1 ? ' item' : ' items'));
    emptyEl.hidden = items.length > 0; footEl.hidden = items.length === 0; listEl.hidden = items.length === 0;
    listEl.textContent = '';
    items.forEach(function (it) {
      var li = el('li', {}, [
        el('img', { class: 'cart-line__img', src: it.img, alt: '', width: '64', height: '64' }),
        el('div', {}, [
          el('p', { class: 'cart-line__name', text: it.name }),
          el('p', { class: 'cart-line__details', text: it.details.join(', ') }),
          el('div', { class: 'cart-line__row' }, [
            el('div', { class: 'stepper', role: 'group', 'aria-label': 'Quantity for ' + it.name }, [
              el('button', { type: 'button', 'data-act': 'dec', 'data-key': it.key, 'aria-label': 'Decrease quantity', text: '\u2212', disabled: it.qty <= 1 ? 'disabled' : null }),
              el('output', { 'aria-live': 'polite', text: String(it.qty) }),
              el('button', { type: 'button', 'data-act': 'inc', 'data-key': it.key, 'aria-label': 'Increase quantity', text: '+', disabled: it.qty >= L.MAX_QTY ? 'disabled' : null })
            ]),
            el('span', { class: 'cart-line__total', text: L.formatMoney(it.unitCents * it.qty) })
          ]),
          el('button', { class: 'cart-line__remove', type: 'button', 'data-act': 'remove', 'data-key': it.key, text: 'Remove' })
        ])
      ]);
      listEl.appendChild(li);
    });
    $('#cartSubtotal').textContent = L.formatMoney(cart.subtotal());
    if (!items.length && !placingOrder && openStack.indexOf(checkoutCtl) !== -1) closeCheckout();
  }
  listEl.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-act]'); if (!b) return;
    var key = b.getAttribute('data-key'), act = b.getAttribute('data-act');
    if (act === 'inc') cart.inc(key); else if (act === 'dec') cart.dec(key); else if (act === 'remove') cart.remove(key);
    // keep keyboard focus on the same control after the list is rebuilt
    var again = listEl.querySelector('button[data-act="' + act + '"][data-key="' + (window.CSS && CSS.escape ? CSS.escape(key) : key) + '"]');
    var target = again && !again.disabled ? again : listEl.querySelector('button[data-act]') || $('#cartClose');
    if (target) target.focus();
  });
  cart.subscribe(renderCart);

  var bumpTimer;
  function bump() {
    cartBtn.classList.remove('bump'); void cartBtn.offsetWidth; cartBtn.classList.add('bump');
    clearTimeout(bumpTimer); bumpTimer = setTimeout(function () { cartBtn.classList.remove('bump'); }, 500);
  }

  /* ---------- Demo checkout ---------- */
  var modal = $('#checkoutModal'), placingOrder = false;
  var checkoutCtl = { node: modal, trigger: null, close: closeCheckout };
  function renderCheckout() {
    var ul = $('#checkoutList'); ul.textContent = '';
    cart.items().forEach(function (it) {
      var label = el('span', {}, [el('strong', { text: it.qty + ' \u00d7 ' + it.name }), el('small', { text: it.details.join(', ') })]);
      ul.appendChild(el('li', {}, [label, el('span', { text: L.formatMoney(it.unitCents * it.qty) })]));
    });
    $('#checkoutSubtotal').textContent = L.formatMoney(cart.subtotal());
  }
  function openCheckout() {
    if (!cart.count()) return;
    renderCheckout();
    $('#checkoutReview').hidden = false; $('#checkoutDone').hidden = true;
    modal.hidden = false; modal.setAttribute('aria-hidden', 'false');
    checkoutCtl.trigger = $('#checkoutOpen');
    openStack.push(checkoutCtl);
    setTimeout(function () { $('#checkoutTitle').scrollIntoView({ block: 'nearest' }); $('#checkoutPlace').focus(); }, 30);
  }
  function closeCheckout() {
    var i = openStack.indexOf(checkoutCtl); if (i === -1) return;
    openStack.splice(i, 1);
    modal.hidden = true; modal.setAttribute('aria-hidden', 'true');
    modal.setAttribute('aria-labelledby', 'checkoutTitle');
    var t = openStack.indexOf(drawerCtl) !== -1 ? $('#checkoutOpen') : cartBtn;
    if (t && t.focus && !t.hidden) t.focus(); else if (cartBtn) cartBtn.focus();
  }
  $('#checkoutOpen').addEventListener('click', openCheckout);
  $('#checkoutClose').addEventListener('click', closeCheckout);
  $('#checkoutBack').addEventListener('click', closeCheckout);
  modal.addEventListener('click', function (e) { if (e.target === modal) closeCheckout(); });
  $('#checkoutPlace').addEventListener('click', function () {
    placingOrder = true;
    cart.clear();                                   // simulated: nothing is sent anywhere
    placingOrder = false;
    $('#checkoutReview').hidden = true; $('#checkoutDone').hidden = false;
    modal.setAttribute('aria-labelledby', 'checkoutDoneTitle');
    $('#checkoutDone h2').id = 'checkoutDoneTitle';
    $('#checkoutFinish').focus();
  });
  $('#checkoutFinish').addEventListener('click', function () {
    closeCheckout(); closeCart();
  });

  /* ---------- Menu ---------- */
  var grid = $('#menuGrid');
  L.PRODUCTS.forEach(function (p) {
    var btn = el('button', { class: 'btn btn--cream', type: 'button', 'aria-label': 'Add ' + p.name + ' to cart', text: 'Add to cart' });
    btn.addEventListener('click', function () {
      cart.add({ kind: 'menu', id: p.id }); bump(); toast(p.name + ' added to cart');
    });
    grid.appendChild(el('article', { class: 'card' }, [
      el('div', { class: 'card__img' }, [el('img', { src: p.img, alt: p.alt, width: '900', height: '900', loading: 'lazy' })]),
      el('div', { class: 'card__body' }, [
        el('div', { class: 'card__row' }, [el('h3', { text: p.name }), el('span', { class: 'card__price', text: L.formatMoney(p.cents) })]),
        el('p', { text: p.desc }),
        btn
      ])
    ]));
  });

  /* ---------- Builder ---------- */
  var cfg = L.normalizeConfig(L.DEFAULT_CONFIG);
  var priceText = function (c) { return c === 0 ? 'Included' : '+' + L.formatMoney(c); };

  function chip(group, type, item, checked, extra) {
    var id = 'opt-' + group + '-' + item.id;
    var input = el('input', { type: type, name: group, id: id, value: item.id });
    if (checked) input.checked = true;
    var label = type === 'checkbox'
      ? el('label', { for: id }, [el('span', { text: item.label }), el('small', { text: priceText(item.cents) })])
      : el('label', { for: id }, [el('span', { text: item.label + (extra ? ' (' + extra + ')' : '') }), el('small', { text: priceText(item.cents) })]);
    return el('div', { class: 'chip' }, [input, label]);
  }
  L.SIZES.forEach(function (s) { $('#optSize').appendChild(chip('size', 'radio', s, s.id === cfg.size, s.detail)); });
  L.SAUCES.forEach(function (s) { $('#optSauce').appendChild(chip('sauce', 'radio', s, s.id === cfg.sauce)); });
  L.CHEESES.forEach(function (s) { $('#optCheese').appendChild(chip('cheese', 'radio', s, s.id === cfg.cheese)); });
  L.TOPPINGS.forEach(function (s) { $('#optToppings').appendChild(chip('toppings', 'checkbox', s, false)); });

  // Preview layers: crust is always present; everything else fades in/out.
  var panPizza = $('#panPizza'), layers = {};
  function addLayer(key, src, base) {
    var img = el('img', { src: src, alt: '', width: '900', height: '900', class: base ? 'base' : 'layer' });
    panPizza.appendChild(img); layers[key] = img;
  }
  addLayer('crust', 'assets/layers/crust.webp', true);
  L.SAUCES.forEach(function (s) { addLayer('sauce:' + s.id, 'assets/layers/sauce-' + s.id + '.webp'); });
  ['mozzarella', 'extra'].forEach(function (c) { addLayer('cheese:' + c, 'assets/layers/cheese-' + c + '.webp'); });
  L.TOPPINGS.forEach(function (t) { addLayer('top:' + t.id, 'assets/layers/top-' + t.id + '.webp'); });

  var SIZE_SCALE = { small: 0.84, medium: 0.92, large: 1 };
  function updateBuilder() {
    cfg = L.normalizeConfig(cfg);
    Object.keys(layers).forEach(function (k) {
      if (k === 'crust') return;
      var on = false, parts = k.split(':');
      if (parts[0] === 'sauce') on = cfg.sauce === parts[1];
      else if (parts[0] === 'cheese') on = cfg.cheese === parts[1];
      else on = cfg.toppings.indexOf(parts[1]) !== -1;
      layers[k].classList.toggle('on', on);
    });
    $('#pan').style.setProperty('--sz', SIZE_SCALE[cfg.size]);
    panPizza.style.setProperty('--sz', SIZE_SCALE[cfg.size]);
    var parts = L.describeConfig(cfg);
    $('#sumText').textContent = parts.join(', ');
    $('#sumPrice').textContent = L.formatMoney(L.customPrice(cfg));
  }
  $('#builderForm').addEventListener('change', function (e) {
    var t = e.target; if (!t || !t.name) return;
    if (t.name === 'toppings') {
      var set = cfg.toppings.slice(), i = set.indexOf(t.value);
      if (t.checked && i === -1) set.push(t.value); else if (!t.checked && i !== -1) set.splice(i, 1);
      cfg.toppings = set;
    } else cfg[t.name] = t.value;
    updateBuilder();
  });
  $('#builderForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var c = L.normalizeConfig(cfg);
    if (cart.add({ kind: 'custom', config: c })) { bump(); toast('Custom pizza added, ' + L.formatMoney(L.customPrice(c))); }
  });
  updateBuilder();

  /* ---------- Mobile nav ---------- */
  var header = $('#siteHeader'), nav = $('#primaryNav'), toggle = $('#menuToggle');
  function setNav(open) {
    nav.classList.toggle('is-open', open); header.classList.toggle('menu-open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    lockScroll(open || openStack.length > 0);
  }
  toggle.addEventListener('click', function () { setNav(toggle.getAttribute('aria-expanded') !== 'true'); });
  $$('a', nav).forEach(function (a) { a.addEventListener('click', function () { setNav(false); }); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true' && !openStack.length) { setNav(false); toggle.focus(); } });
  window.matchMedia('(min-width: 900px)').addEventListener('change', function (m) { if (m.matches) setNav(false); });

  /* ---------- Scroll effects (one rAF-throttled handler) ---------- */
  var stage = $('#expStage'), exp = $('#experience'), words = $$('.exp__word'), heroImg = $('#heroPizza');
  var ticking = false, step = -1;
  function onScroll() {
    header.classList.toggle('is-stuck', window.scrollY > 24);
    if (reduceMotion) return;
    var vh = window.innerHeight, r = exp.getBoundingClientRect();
    var total = r.height - vh;
    var p = total > 0 ? Math.min(1, Math.max(0, -r.top / total)) : 0;
    stage.style.setProperty('--p', p.toFixed(4));
    var s = p < 0.34 ? 0 : p < 0.68 ? 1 : 2;
    if (s !== step) { step = s; words.forEach(function (w, i) { w.classList.toggle('is-on', i === s); }); }
    if (window.scrollY < vh * 1.5) heroImg.style.setProperty('--rot', (window.scrollY * 0.04).toFixed(2) + 'deg');
  }
  window.addEventListener('scroll', function () {
    if (ticking) return; ticking = true;
    requestAnimationFrame(function () { onScroll(); ticking = false; });
  }, { passive: true });
  window.addEventListener('resize', onScroll);
  onScroll();

  renderCart();
})();

/* PIZERIA — catalog, pricing and cart logic (no DOM access, so it can be unit-tested in Node).
   All money is handled in integer cents to avoid floating-point drift. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PizeriaLogic = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var BASE_CENTS = 1200;
  var MAX_QTY = 20;
  var STORAGE_KEY = 'pizeria.cart.v1';

  var SIZES = [
    { id: 'small', label: 'Small', detail: '10 in', cents: 0 },
    { id: 'medium', label: 'Medium', detail: '12 in', cents: 200 },
    { id: 'large', label: 'Large', detail: '14 in', cents: 400 }
  ];
  var SAUCES = [
    { id: 'tomato', label: 'Tomato', cents: 0 },
    { id: 'white', label: 'White', cents: 0 },
    { id: 'spicy', label: 'Spicy', cents: 0 }
  ];
  var CHEESES = [
    { id: 'none', label: 'No cheese', cents: 0 },
    { id: 'mozzarella', label: 'Mozzarella', cents: 100 },
    { id: 'extra', label: 'Extra cheese', cents: 200 }
  ];
  var TOPPINGS = [
    { id: 'pepperoni', label: 'Pepperoni', cents: 200 },
    { id: 'mushrooms', label: 'Mushrooms', cents: 100 },
    { id: 'olives', label: 'Olives', cents: 100 },
    { id: 'basil', label: 'Basil', cents: 100 },
    { id: 'jalapenos', label: 'Jalape\u00f1o', cents: 100 },
    { id: 'onion', label: 'Onion', cents: 100 }
  ];
  var PRODUCTS = [
    { id: 'margherita', name: 'Margherita', cents: 1400, img: 'assets/pizzas/margherita.webp',
      desc: 'Tomato, mozzarella and fresh basil on a blistered crust.',
      alt: 'Illustrated top-down Margherita pizza with basil leaves' },
    { id: 'spicy-pepperoni', name: 'Spicy Pepperoni', cents: 1600, img: 'assets/pizzas/spicy-pepperoni.webp',
      desc: 'Spicy tomato, mozzarella, pepperoni and sliced jalape\u00f1o.',
      alt: 'Illustrated top-down pepperoni pizza with jalape\u00f1o slices' },
    { id: 'truffle-mushroom', name: 'Truffle Mushroom', cents: 1800, img: 'assets/pizzas/truffle-mushroom.webp',
      desc: 'White sauce, mozzarella, mushrooms, basil and a truffle oil finish.',
      alt: 'Illustrated top-down mushroom pizza on white sauce' },
    { id: 'garden-veggie', name: 'Garden Veggie', cents: 1500, img: 'assets/pizzas/garden-veggie.webp',
      desc: 'Tomato, mozzarella, olives, mushrooms, red onion and basil.',
      alt: 'Illustrated top-down vegetable pizza with olives and onion' }
  ];

  function byId(list, id) {
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return null;
  }

  function formatMoney(cents) {
    var c = Math.round(Number(cents));
    if (!isFinite(c)) c = 0;
    var neg = c < 0; c = Math.abs(c);
    var dollars = Math.floor(c / 100), rem = c % 100;
    return (neg ? '-' : '') + '$' + dollars + '.' + (rem < 10 ? '0' : '') + rem;
  }

  var DEFAULT_CONFIG = { size: 'medium', sauce: 'tomato', cheese: 'mozzarella', toppings: [] };

  /* Coerce anything (including tampered storage) into a valid configuration. */
  function normalizeConfig(c) {
    c = c && typeof c === 'object' ? c : {};
    var tops = Array.isArray(c.toppings) ? c.toppings : [];
    var seen = {}, clean = [];
    TOPPINGS.forEach(function (t) { // iterate catalog order => stable, de-duplicated list
      if (tops.indexOf(t.id) !== -1 && !seen[t.id]) { seen[t.id] = 1; clean.push(t.id); }
    });
    return {
      size: byId(SIZES, c.size) ? c.size : DEFAULT_CONFIG.size,
      sauce: byId(SAUCES, c.sauce) ? c.sauce : DEFAULT_CONFIG.sauce,
      cheese: byId(CHEESES, c.cheese) ? c.cheese : DEFAULT_CONFIG.cheese,
      toppings: clean
    };
  }

  function customPrice(config) {
    var c = normalizeConfig(config);
    var total = BASE_CENTS + byId(SIZES, c.size).cents + byId(SAUCES, c.sauce).cents + byId(CHEESES, c.cheese).cents;
    c.toppings.forEach(function (id) { total += byId(TOPPINGS, id).cents; });
    return total;
  }

  function configKey(config) {
    var c = normalizeConfig(config);
    return 'custom:' + c.size + '|' + c.sauce + '|' + c.cheese + '|' + c.toppings.join(',');
  }

  function describeConfig(config) {
    var c = normalizeConfig(config);
    var parts = [byId(SIZES, c.size).label + ' (' + byId(SIZES, c.size).detail + ')',
      byId(SAUCES, c.sauce).label + ' sauce', byId(CHEESES, c.cheese).label];
    parts.push(c.toppings.length ? c.toppings.map(function (id) { return byId(TOPPINGS, id).label; }).join(', ') : 'No toppings');
    return parts;
  }

  function clampQty(q) {
    q = Math.floor(Number(q));
    if (!isFinite(q) || q < 1) return 1;
    return Math.min(q, MAX_QTY);
  }

  /* Turn a stored line into a displayable item with a price recomputed from the catalog. */
  function resolve(line) {
    if (!line || typeof line !== 'object') return null;
    var qty = clampQty(line.qty);
    if (line.kind === 'menu') {
      var p = byId(PRODUCTS, line.id);
      if (!p) return null;
      return { key: 'menu:' + p.id, kind: 'menu', id: p.id, name: p.name, details: [p.desc], img: p.img,
        unitCents: p.cents, qty: qty };
    }
    if (line.kind === 'custom') {
      var cfg = normalizeConfig(line.config);
      return { key: configKey(cfg), kind: 'custom', config: cfg, name: 'Custom pizza', details: describeConfig(cfg),
        img: 'assets/pizzas/custom-thumb.webp', unitCents: customPrice(cfg), qty: qty };
    }
    return null;
  }

  function createCart(storage) {
    var lines = [];   // [{kind, id?, config?, qty}]
    var listeners = [];

    function keyOf(line) { var r = resolve(line); return r ? r.key : null; }
    function emit() { save(); listeners.forEach(function (fn) { try { fn(); } catch (e) { /* ignore UI errors */ } }); }
    function save() {
      if (!storage) return;
      try { storage.setItem(STORAGE_KEY, JSON.stringify(lines)); } catch (e) { /* quota/private mode */ }
    }
    function load() {
      lines = [];
      if (!storage) return;
      try {
        var raw = JSON.parse(storage.getItem(STORAGE_KEY) || '[]');
        if (!Array.isArray(raw)) return;
        raw.forEach(function (l) { add(l, true); });
      } catch (e) { lines = []; }
    }

    function add(spec, silent) {
      var r = resolve(spec);
      if (!r) return false;
      var found = null;
      for (var i = 0; i < lines.length; i++) if (keyOf(lines[i]) === r.key) { found = lines[i]; break; }
      var addQty = spec && spec.qty !== undefined ? clampQty(spec.qty) : 1;
      if (found) found.qty = clampQty(found.qty + addQty);
      else lines.push(r.kind === 'menu' ? { kind: 'menu', id: r.id, qty: addQty } : { kind: 'custom', config: r.config, qty: addQty });
      if (!silent) emit();
      return true;
    }
    function find(key) { for (var i = 0; i < lines.length; i++) if (keyOf(lines[i]) === key) return lines[i]; return null; }
    function setQty(key, q) {
      var l = find(key); if (!l) return false;
      var n = Number(q);
      if (!isFinite(n)) return false;          // garbage input: leave unchanged
      l.qty = clampQty(n); emit(); return true;
    }
    function inc(key) { var l = find(key); return l ? setQty(key, l.qty + 1) : false; }
    function dec(key) { var l = find(key); return l ? setQty(key, l.qty - 1) : false; } // never below 1; use remove()
    function remove(key) {
      var n = lines.length;
      lines = lines.filter(function (l) { return keyOf(l) !== key; });
      if (lines.length !== n) { emit(); return true; } return false;
    }
    function clear() { lines = []; emit(); }
    function items() { return lines.map(resolve).filter(Boolean); }
    function count() { return items().reduce(function (s, i) { return s + i.qty; }, 0); }
    function subtotal() { return items().reduce(function (s, i) { return s + i.unitCents * i.qty; }, 0); }
    function subscribe(fn) { listeners.push(fn); }

    load();
    return { add: add, setQty: setQty, inc: inc, dec: dec, remove: remove, clear: clear, items: items,
      count: count, subtotal: subtotal, subscribe: subscribe };
  }

  return { BASE_CENTS: BASE_CENTS, MAX_QTY: MAX_QTY, STORAGE_KEY: STORAGE_KEY, SIZES: SIZES, SAUCES: SAUCES,
    CHEESES: CHEESES, TOPPINGS: TOPPINGS, PRODUCTS: PRODUCTS, DEFAULT_CONFIG: DEFAULT_CONFIG,
    formatMoney: formatMoney, normalizeConfig: normalizeConfig, customPrice: customPrice, configKey: configKey,
    describeConfig: describeConfig, clampQty: clampQty, resolve: resolve, createCart: createCart };
});

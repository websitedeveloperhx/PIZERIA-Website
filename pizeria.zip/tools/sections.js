// Run: NODE_PATH=$(npm root -g) PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers node tools/sections.js <width> <height>
const { chromium } = require('playwright'); const path = require('path');
const [w, h] = [+process.argv[2] || 1440, +process.argv[3] || 900];
(async () => {
  const b = await chromium.launch(); const pg = await (await b.newContext({ viewport: { width: w, height: h } })).newPage();
  await pg.goto('file://' + path.resolve(__dirname, '../index.html')); await pg.waitForTimeout(500);
  await pg.addStyleTag({ content: 'html{scroll-behavior:auto!important}' });
  const ids = ['menu', 'builder', 'why-title', 'story', 'guests', 'visit', 'order'];
  for (const id of ids) {
    await pg.evaluate(i => { const e = document.getElementById(i); const s = e.closest('section') || e; window.scrollTo(0, s.offsetTop - 60); }, id);
    await pg.waitForTimeout(700);
    await pg.screenshot({ path: `/home/claude/shots/sec-${w}-${id}.png` });
  }
  await pg.evaluate(() => window.scrollTo(0, document.body.scrollHeight)); await pg.waitForTimeout(500);
  await pg.screenshot({ path: `/home/claude/shots/sec-${w}-footer.png` });
  await b.close();
})();

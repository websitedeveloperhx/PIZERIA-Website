// Run: node tools/test-logic.js
const L = require('../js/logic.js');
let pass = 0, fail = 0;
const eq = (a, b, msg) => { if (JSON.stringify(a) === JSON.stringify(b)) pass++; else { fail++; console.log('FAIL', msg, '\n  got', JSON.stringify(a), '\n  want', JSON.stringify(b)); } };
const mem = () => { const m = {}; return { getItem: k => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, _m: m }; };

// pricing
eq(L.customPrice(L.DEFAULT_CONFIG), 1500, 'default medium+mozz = 12+2+1');
eq(L.customPrice({ size: 'small', sauce: 'tomato', cheese: 'none', toppings: [] }), 1200, 'cheapest');
eq(L.customPrice({ size: 'large', sauce: 'spicy', cheese: 'extra', toppings: ['pepperoni','mushrooms','olives','basil','jalapenos','onion'] }), 1200+400+200+700, 'max');
eq(L.customPrice({ size: 'bogus', sauce: 'x', cheese: 'y', toppings: ['nope', 'basil', 'basil'] }), 1200+200+100+100, 'invalid ids fall back to defaults, dupes dropped');
eq(L.customPrice(null), 1500, 'null config');
eq(L.formatMoney(1500), '$15.00', 'fmt'); eq(L.formatMoney(1205), '$12.05', 'fmt pad'); eq(L.formatMoney(NaN), '$0.00', 'fmt NaN');
// key: topping order must not create separate lines
eq(L.configKey({ toppings: ['onion', 'basil'] }), L.configKey({ toppings: ['basil', 'onion'] }), 'order-independent key');
// cart
const st = mem(); const c = L.createCart(st);
c.add({ kind: 'menu', id: 'margherita' }); c.add({ kind: 'menu', id: 'margherita' });
eq([c.count(), c.subtotal()], [2, 2800], 'two margheritas');
c.add({ kind: 'custom', config: { size: 'large', toppings: ['pepperoni'] } });
c.add({ kind: 'custom', config: { size: 'large', toppings: ['pepperoni'] } });
c.add({ kind: 'custom', config: { size: 'small', toppings: ['pepperoni'] } });
eq(c.items().length, 3, 'same config merges, different config separate');
const big = c.items().find(i => i.config && i.config.size === 'large');
eq([big.qty, big.unitCents], [2, 1200+400+100+200], 'large custom qty/price');
c.inc(big.key); eq(c.items().find(i => i.key === big.key).qty, 3, 'inc');
c.dec(big.key); c.dec(big.key); c.dec(big.key); eq(c.items().find(i => i.key === big.key).qty, 1, 'dec floors at 1');
c.setQty(big.key, 'abc'); eq(c.items().find(i => i.key === big.key).qty, 1, 'garbage ignored');
c.setQty(big.key, -5); eq(c.items().find(i => i.key === big.key).qty, 1, 'negative clamps to 1');
c.setQty(big.key, 9999); eq(c.items().find(i => i.key === big.key).qty, L.MAX_QTY, 'max clamp');
c.setQty(big.key, 2.9); eq(c.items().find(i => i.key === big.key).qty, 2, 'fractional floors');
eq(c.add({ kind: 'menu', id: 'nope' }), false, 'unknown product rejected');
eq(c.add({ kind: 'weird' }), false, 'unknown kind rejected');
const expected = 2*1400 + 2*(1200+400+100+200) + 1*(1200+0+100+200);
eq(c.subtotal(), expected, 'subtotal after changes');
c.remove(big.key); eq(c.items().length, 2, 'remove');
eq(c.remove('menu:ghost'), false, 'remove missing');
// persistence + tamper resistance
const c2 = L.createCart(st); eq([c2.count(), c2.subtotal()], [c.count(), c.subtotal()], 'reloaded from storage');
st.setItem(L.STORAGE_KEY, JSON.stringify([{ kind: 'menu', id: 'margherita', qty: 2, unitCents: 1 }, { kind: 'menu', id: 'zzz', qty: 1 }, 7, null, { kind: 'custom', config: { size: 'huge' }, qty: 99 }]));
const c3 = L.createCart(st); eq(c3.items().map(i => [i.key, i.qty, i.unitCents]), [['menu:margherita', 2, 1400], [L.configKey({}), L.MAX_QTY, 1500]], 'tampered storage sanitised, prices recomputed');
st.setItem(L.STORAGE_KEY, '{not json'); eq(L.createCart(st).count(), 0, 'corrupt JSON => empty');
eq(L.createCart(null).count(), 0, 'no storage works');
let notified = 0; const c4 = L.createCart(mem()); c4.subscribe(() => notified++); c4.add({ kind: 'menu', id: 'garden-veggie' }); c4.clear(); eq([notified, c4.count()], [2, 0], 'subscribe + clear');
console.log(`${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);

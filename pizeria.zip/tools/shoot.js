// Run: NODE_PATH=$(npm root -g) PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers node tools/shoot.js
const { chromium } = require('playwright');
const path = require('path');
const url = 'file://' + path.resolve(__dirname, '../index.html');
const widths = [[360,740],[390,844],[430,932],[768,1024],[1024,768],[1440,900]];
(async () => {
  const b = await chromium.launch();
  for (const [w,h] of widths) {
    const ctx = await b.newContext({ viewport:{width:w,height:h}, deviceScaleFactor:1 });
    const pg = await ctx.newPage(); const errs=[];
    pg.on('console', m => { if (m.type()==='error') errs.push(m.text()); });
    pg.on('pageerror', e => errs.push('PAGEERROR '+e.message));
    pg.on('requestfailed', r => { if (!/fonts\.(googleapis|gstatic)/.test(r.url())) errs.push('REQFAIL '+r.url()); });
    await pg.goto(url); await pg.waitForTimeout(1800);
    const ov = await pg.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
    console.log(w, 'overflow:', ov.sw>ov.cw ? 'YES '+ov.sw+'>'+ov.cw : 'no', 'errors:', errs.filter(e=>!/ERR_(NAME|INTERNET|CONNECTION)/.test(e)).join(' | ')||'none');
    await pg.screenshot({ path:`/home/claude/shots/hero-${w}.png` });
    await ctx.close();
  }
  await b.close();
})();

// Run: NODE_PATH=$(npm root -g) PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers node tools/e2e.js
const { chromium } = require('playwright');
const path = require('path');
const url = 'file://' + path.resolve(__dirname, '../index.html');
let pass = 0, fail = 0;
const ok = (c, msg, extra) => { if (c) pass++; else { fail++; console.log('FAIL:', msg, extra !== undefined ? '=> ' + JSON.stringify(extra) : ''); } };
const settle = async pg => { let last = -1, same = 0; for (let i = 0; i < 80 && same < 8; i++) { const y = await pg.evaluate(() => Math.round(scrollY)); same = y === last ? same + 1 : 0; last = y; await pg.waitForTimeout(100); } };
const txt = async (pg, s) => (await pg.locator(s).first().innerText()).trim();

(async () => {
  const b = await chromium.launch();
  const errs = [];
  async function fresh(w = 1440, h = 900, opts = {}) {
    const ctx = await b.newContext({ viewport: { width: w, height: h }, ...opts });
    const pg = await ctx.newPage();
    pg.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
    pg.on('console', m => { if (m.type() === 'error' && !/ERR_(NAME|INTERNET|CONNECTION)|Failed to load resource/.test(m.text())) errs.push(m.text()); });
    await pg.goto(url); await pg.waitForTimeout(400);
    return { ctx, pg };
  }

  // ---------- links / anchors ----------
  {
    const { ctx, pg } = await fresh();
    const bad = await pg.evaluate(() => [...document.querySelectorAll('a[href^="#"]')].map(a => a.getAttribute('href')).filter(h => h.length > 1 && !document.querySelector(h)));
    ok(bad.length === 0, 'all in-page anchors resolve', bad);
    for (const [label, id] of [['Menu', 'menu'], ['Our Story', 'story'], ['Build Your Pizza', 'builder']]) {
      await pg.locator('#primaryNav').getByText(label, { exact: true }).click(); await settle(pg);
      const top = await pg.evaluate(i => document.getElementById(i).getBoundingClientRect().top, id);
      ok(top > -5 && top < 140, `nav "${label}" scrolls to #${id}`, top);
    }
    ok(await pg.locator('#menuGrid .card').count() === 4, '4 signature pizzas rendered');
    ok(await pg.locator('.skip-link').count() === 1, 'skip link present');
    await ctx.close();
  }

  // ---------- menu + cart ----------
  {
    const { ctx, pg } = await fresh();
    ok(await pg.locator('#cartCount').isHidden(), 'cart badge hidden when empty');
    await pg.locator('#cartOpen').click(); await pg.waitForTimeout(500);
    ok(await pg.locator('#cartEmpty').isVisible(), 'empty-cart state visible');
    ok(await pg.locator('#checkoutOpen').isHidden(), 'checkout hidden when empty');
    await pg.keyboard.press('Escape'); await pg.waitForTimeout(500);
    ok(!(await pg.locator('#cartDrawer').evaluate(e => e.classList.contains('is-open'))), 'Esc closes drawer');
    ok(await pg.evaluate(() => document.activeElement.id) === 'cartOpen', 'focus returns to cart button');

    const btns = pg.locator('#menuGrid .card .btn');
    await btns.nth(0).click(); await btns.nth(0).click(); await btns.nth(1).click();
    ok(await txt(pg, '#cartCount') === '3', 'badge counts items (2+1)', await txt(pg, '#cartCount'));
    ok((await pg.locator('#cartOpen').getAttribute('aria-label')).includes('3 items'), 'cart button aria-label updates');
    ok((await txt(pg, '#toast')).includes('Spicy Pepperoni'), 'toast announces add');
    await pg.locator('#cartOpen').click(); await pg.waitForTimeout(500);
    ok(await pg.locator('#cartList li').count() === 2, 'two lines (merged duplicates)');
    ok(await txt(pg, '#cartSubtotal') === '$44.00', 'subtotal 2x14 + 16', await txt(pg, '#cartSubtotal'));
    const line0 = pg.locator('#cartList li').nth(0);
    await line0.locator('[data-act=inc]').click();
    ok(await txt(pg, '#cartSubtotal') === '$58.00', 'inc updates subtotal', await txt(pg, '#cartSubtotal'));
    await pg.locator('#cartList li').nth(0).locator('[data-act=dec]').click();
    await pg.locator('#cartList li').nth(0).locator('[data-act=dec]').click();
    ok(await pg.locator('#cartList li').nth(0).locator('[data-act=dec]').isDisabled(), 'dec disabled at qty 1');
    ok(await txt(pg, '#cartSubtotal') === '$30.00', 'dec twice => 14 + 16 = 30', await txt(pg, '#cartSubtotal'));
    ok(await pg.locator('#cartList li').nth(0).locator('[data-act=dec]').getAttribute('disabled') !== 'null', 'no literal "null" disabled attr');
    // tab trap: focus stays inside drawer
    for (let i = 0; i < 14; i++) await pg.keyboard.press('Tab');
    ok(await pg.evaluate(() => document.getElementById('cartDrawer').contains(document.activeElement)), 'focus trapped in drawer');
    await pg.locator('#cartList li').nth(1).locator('[data-act=remove]').click();
    ok(await pg.locator('#cartList li').count() === 1 && await txt(pg, '#cartSubtotal') === '$14.00', 'remove works', await txt(pg, '#cartSubtotal'));
    await pg.locator('#cartClear').click();
    ok(await pg.locator('#cartEmpty').isVisible() && await pg.locator('#cartCount').isHidden(), 'clear => empty state, badge hidden');
    await ctx.close();
  }

  // ---------- builder ----------
  {
    const { ctx, pg } = await fresh();
    
    const price = () => txt(pg, '#sumPrice');
    const click = async id => { await pg.evaluate(i => document.getElementById(i).scrollIntoView({ block: 'center', behavior: 'instant' }), id); await pg.locator('#' + id).click(); };
    ok(await price() === '$15.00', 'default $15.00 (base 12 + medium 2 + mozzarella 1)', await price());
    ok(await pg.locator('#opt-size-medium').isChecked() && await pg.locator('#opt-sauce-tomato').isChecked() && await pg.locator('#opt-cheese-mozzarella').isChecked(), 'sensible defaults checked');
    await click('opt-size-large'); ok(await price() === '$17.00', 'large => 17', await price());
    await click('opt-size-small'); ok(await price() === '$13.00', 'small => 13', await price());
    await click('opt-size-large');
    await click('opt-cheese-extra'); ok(await price() === '$18.00', 'extra cheese => 18', await price());
    await click('opt-cheese-none'); ok(await price() === '$16.00', 'no cheese => 16', await price());
    await click('opt-cheese-mozzarella');
    await click('opt-toppings-pepperoni'); ok(await price() === '$19.00', '+pepperoni => 19', await price());
    await click('opt-toppings-olives'); await click('opt-toppings-basil'); ok(await price() === '$21.00', '+olives+basil => 21', await price());
    await click('opt-toppings-olives'); ok(await price() === '$20.00', 'deselect olives => 20', await price());
    await click('opt-sauce-spicy'); ok(await price() === '$20.00', 'sauce free', await price());
    const on = await pg.evaluate(() => [...document.querySelectorAll('#panPizza img.on')].map(i => i.getAttribute('src').split('/').pop()));
    ok(['sauce-spicy.webp', 'cheese-mozzarella.webp', 'top-pepperoni.webp', 'top-basil.webp'].every(f => on.includes(f)) && on.length === 4, 'preview layers match selections', on);
    ok((await txt(pg, '#sumText')) === 'Large (14 in), Spicy sauce, Mozzarella, Pepperoni, Basil', 'summary text', await txt(pg, '#sumText'));
    // keyboard: toggle a topping with Space
    await pg.locator('#opt-toppings-onion').focus(); await pg.keyboard.press('Space');
    ok(await price() === '$21.00', 'keyboard Space toggles topping', await price());
    await pg.keyboard.press('Space'); ok(await price() === '$20.00', 'Space again untoggles');
    // add to cart, configuration preserved, identical merges, different separates
    await pg.locator('#builderForm button[type=submit]').click();
    await pg.locator('#builderForm button[type=submit]').click();
    await click('opt-size-small');
    await pg.locator('#builderForm button[type=submit]').click();
    await pg.locator('#cartOpen').click(); await pg.waitForTimeout(500);
    ok(await pg.locator('#cartList li').count() === 2, 'distinct configs => 2 lines');
    const d = await pg.locator('#cartList li').allInnerTexts();
    ok(d[0].includes('Large (14 in), Spicy sauce, Mozzarella, Pepperoni, Basil') && d[0].includes('$40.00'), 'config + qty2 total preserved', d[0]);
    ok(d[1].includes('Small (10 in)') && d[1].includes('$16.00'), 'second config priced $16', d[1]);
    ok(await txt(pg, '#cartSubtotal') === '$56.00', 'subtotal 56', await txt(pg, '#cartSubtotal'));
    // persistence
    await pg.reload(); await pg.waitForTimeout(400);
    ok(await txt(pg, '#cartCount') === '3', 'cart persisted across reload', await txt(pg, '#cartCount'));
    await pg.locator('#cartOpen').click(); await pg.waitForTimeout(500);
    ok(await txt(pg, '#cartSubtotal') === '$56.00', 'subtotal persisted');
    // tamper localStorage: bad data must not crash, prices recomputed
    await pg.evaluate(() => localStorage.setItem('pizeria.cart.v1', '[{"kind":"menu","id":"margherita","qty":"5","unitCents":1}]'));
    await pg.reload(); await pg.waitForTimeout(300);
    await pg.locator('#cartOpen').click(); await pg.waitForTimeout(500);
    ok(await txt(pg, '#cartSubtotal') === '$70.00', 'tampered price ignored, recomputed', await txt(pg, '#cartSubtotal'));
    // ---- demo checkout ----
    await pg.locator('#checkoutOpen').click(); await pg.waitForTimeout(300);
    ok(await pg.locator('#checkoutModal').isVisible(), 'checkout modal opens');
    ok((await txt(pg, '#checkoutModal .demo-banner')).includes('Simulated'), 'checkout labelled simulated');
    ok(await pg.locator('#checkoutModal input').count() === 0, 'no input fields (no card data collected)');
    ok(await txt(pg, '#checkoutSubtotal') === '$70.00', 'checkout subtotal');
    await pg.locator('#checkoutPlace').click(); await pg.waitForTimeout(300);
    ok(await pg.locator('#checkoutDone').isVisible() && await pg.locator('#checkoutModal').isVisible(), 'confirmation stays visible after cart clears');
    ok((await txt(pg, '#checkoutDone')).includes('Nothing was ordered or charged'), 'confirmation states nothing was ordered');
    ok(await txt(pg, '#cartSubtotal') === '$0.00' && await pg.locator('#cartCount').isHidden(), 'cart emptied');
    await pg.locator('#checkoutFinish').click(); await pg.waitForTimeout(500);
    ok(await pg.locator('#checkoutModal').isHidden() && !(await pg.locator('#cartDrawer').evaluate(e => e.classList.contains('is-open'))), 'finish closes modal + drawer');
    ok(!(await pg.evaluate(() => document.body.classList.contains('is-locked'))), 'scroll lock released');
    await ctx.close();
  }

  // ---------- mobile nav + touch targets ----------
  {
    const { ctx, pg } = await fresh(360, 740);
    const tg = pg.locator('#menuToggle');
    ok(await pg.locator('#primaryNav a').first().isHidden(), 'nav hidden on mobile by default');
    await tg.click(); await pg.waitForTimeout(500);
    ok(await tg.getAttribute('aria-expanded') === 'true' && await pg.locator('#primaryNav a').first().isVisible(), 'mobile menu opens');
    await pg.keyboard.press('Escape'); await pg.waitForTimeout(500);
    ok(await tg.getAttribute('aria-expanded') === 'false' && await pg.locator('#primaryNav a').first().isHidden(), 'Esc closes mobile menu');
    await tg.click(); await pg.waitForTimeout(400);
    await pg.locator('#primaryNav').getByText('Our Story').click(); await settle(pg);
    ok(await tg.getAttribute('aria-expanded') === 'false', 'tapping a link closes menu');
    ok(await pg.evaluate(() => document.getElementById('story').getBoundingClientRect().top < 120), 'and scrolls to story');
    const small = await pg.evaluate(() => [...document.querySelectorAll('button, a.btn, .chip label, .footer nav a')].filter(e => e.offsetParent !== null).map(e => { const r = e.getBoundingClientRect(); return { t: (e.textContent || e.getAttribute('aria-label') || '').trim().slice(0, 24), w: Math.round(r.width), h: Math.round(r.height) }; }).filter(x => x.h < 40 || x.w < 40));
    ok(small.length === 0, 'touch targets >= 40px at 360px', small);
    // cart drawer fits phone
    await pg.locator('#menuGrid .card .btn').first().click();
    await pg.locator('#cartOpen').click(); await pg.waitForTimeout(500);
    const w = await pg.locator('#cartDrawer').evaluate(e => e.getBoundingClientRect().width);
    ok(w <= 360, 'drawer fits 360px viewport', w);
    await ctx.close();
  }

  // ---------- scroll stage, images, reduced motion ----------
  {
    const { ctx, pg } = await fresh(1440, 900);
    const stageTop = await pg.evaluate(() => document.getElementById('experience').offsetTop);
    const total = await pg.evaluate(() => document.getElementById('experience').offsetHeight - innerHeight);
    const seen = [];
    for (const f of [0.1, 0.5, 0.9]) {
      await pg.evaluate(y => window.scrollTo({ top: y, behavior: 'instant' }), stageTop + total * f); await pg.waitForTimeout(900);
      const s = await pg.evaluate(() => ({ p: +document.getElementById('expStage').style.getPropertyValue('--p'), word: document.querySelector('.exp__word.is-on span').textContent }));
      seen.push(s);
      await pg.screenshot({ path: `/home/claude/shots/exp-${Math.round(f * 100)}.png` });
    }
    ok(seen[0].word === 'Fresh.' && seen[1].word === 'Hot.' && seen[2].word === 'Handcrafted.', 'scroll steps through 3 words', seen);
    ok(seen[0].p < seen[1].p && seen[1].p < seen[2].p, 'progress increases', seen);
    // load all lazy images by scrolling the whole page
    await pg.evaluate(async () => { for (let y = 0; y < document.body.scrollHeight; y += 500) { window.scrollTo(0, y); await new Promise(r => setTimeout(r, 120)); } });
    await pg.waitForTimeout(800);
    const broken = await pg.evaluate(() => [...document.images].filter(i => !i.complete || i.naturalWidth === 0).map(i => i.getAttribute('src')));
    ok(broken.length === 0, 'all images load', broken);
    const noAlt = await pg.evaluate(() => [...document.images].filter(i => !i.hasAttribute('alt')).length);
    ok(noAlt === 0, 'every img has alt attribute');
    const h1 = await pg.locator('h1').count(); ok(h1 === 1, 'exactly one h1');
    await pg.evaluate(() => window.scrollTo(0, document.getElementById('builder').offsetTop)); await pg.waitForTimeout(300);
    await pg.screenshot({ path: '/home/claude/shots/builder-1440.png' });
    await pg.evaluate(() => window.scrollTo(0, document.getElementById('menu').offsetTop)); await pg.waitForTimeout(300);
    await pg.screenshot({ path: '/home/claude/shots/menu-1440.png' });
    await ctx.close();

    const r = await fresh(390, 844, { reducedMotion: 'reduce' });
    const info = await r.pg.evaluate(() => ({ h: document.getElementById('experience').offsetHeight, vh: innerHeight, pos: getComputedStyle(document.getElementById('expStage')).position, vis: [...document.querySelectorAll('.exp__word')].map(w => getComputedStyle(w).opacity) }));
    ok(info.h < info.vh * 3 && info.pos === 'relative' && info.vis.every(o => o === '1'), 'reduced motion: no pinned scroll, all words visible', info);
    const heroSpan = await r.pg.evaluate(() => getComputedStyle(document.querySelector('.hero__title .line > span')).transform);
    ok(heroSpan === 'none' || heroSpan === 'matrix(1, 0, 0, 1, 0, 0)', 'reduced motion: hero text not translated', heroSpan);
    await r.ctx.close();
  }

  ok(errs.length === 0, 'no console/page errors', errs);
  console.log(`${pass} passed, ${fail} failed`);
  await b.close(); process.exit(fail ? 1 : 0);
})();
